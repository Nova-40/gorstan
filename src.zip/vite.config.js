// MIT License © 2025 Geoff Webster
// Gorstan v2.5
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
});