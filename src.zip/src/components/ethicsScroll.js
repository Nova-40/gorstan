export const ethicsScroll = {
  id: "ethicsScroll",
  name: "Scroll of the Lattice Accord",
  description: "A faded parchment bearing the Lattice Accord — unreadable to most.",
  readable: true
};
