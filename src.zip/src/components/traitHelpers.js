export function playerHasTrait(traitName, state) {
  return (state.traits || []).includes(traitName);
}
