// Gorstan Game Module — v3.0.3
import React, { useState, useEffect, useReducer, useRef } from 'react';
import { GameContext, gameReducer, initialState } from './engine/GameContext.jsx';
import WelcomeScreen from './components/WelcomeScreen';
import PlayerNameCapture from './components/PlayerNameCapture';
import TeletypeIntro from './components/TeletypeIntro';
import PortalTransition from './components/PortalTransition';
import GameEngine from './engine/GameEngine.jsx';

/**
 * AppCore
 * Main controller for Gorstan game flow and state transitions.
 * @component
 * @returns {JSX.Element}
 */
const AppCore = () => {
  const [stage, setStage] = useState('welcome');
  const [state, dispatch] = useReducer(gameReducer, initialState);
  const timerRef = useRef(null);

  const cancelTimer = () => {
    if (timerRef.current) {
      clearTimeout(timerRef.current);
      timerRef.current = null;
      console.log("[AppCore] Timer cancelled");
    }
  };

  const setStageWithCancel = (newStage) => {
    cancelTimer();
    setStage(newStage);
  };

  useEffect(() => {
    console.log("[AppCore] Stage changed:", stage);
    cancelTimer();

    switch (stage) {
      case 'portal':
        timerRef.current = setTimeout(() => {
          if (stage !== 'portal') return;
          console.log("[AppCore] Transition: portal → room9");
          dispatch({ type: 'SET_ROOM', payload: 'room9' });
          setStage('game');
        }, 6000);
        break;
      case 'splat':
        timerRef.current = setTimeout(() => {
          if (stage !== 'splat') return;
          console.log("[AppCore] Transition: splat → waitreset");
          setStage('waitreset');
        }, 3000);
        break;
      case 'waitreset':
        timerRef.current = setTimeout(() => {
          if (stage !== 'waitreset') return;
          console.log("[AppCore] Transition: waitreset → introReset");
          dispatch({ type: 'SET_ROOM', payload: 'introReset' });
          setStage('game');
        }, 3000);
        break;
      case 'sipreset':
        timerRef.current = setTimeout(() => {
          if (stage !== 'sipreset') return;
          console.log("[AppCore] Transition: sipreset → lattice → game");
          dispatch({ type: 'SET_ROOM', payload: 'room21' });
          setStage('game');
        }, 3000);
        break;
      case 'portallattice':
        timerRef.current = setTimeout(() => {
          if (stage !== 'portallattice') return;
          console.log("[AppCore] Transition: portallattice → room21 → game");
          dispatch({ type: 'SET_ROOM', payload: 'room21' });
          setStage('game');
        }, 6000);
        break;
    }
  }, [stage, dispatch]);

  const handleNameSubmit = (name) => {
    cancelTimer();
    console.log("[AppCore] Player name submitted:", name);
    dispatch({ type: 'SET_PLAYER_NAME', payload: name });
    setStage('teletype');
  };

  const handleJump = () => {
    cancelTimer();
    console.log("[AppCore] TeletypeIntro: Jump selected");
    dispatch({ type: 'SET_INTRO_CHOICE', payload: 'jump' });
    dispatch({ type: 'INCREMENT_SCORE', payload: 10 });
    dispatch({ type: 'ADD_ITEM', payload: 'coffee' });
    setStage('portal');
  };

  const handleWait = () => {
    cancelTimer();
    console.log("[AppCore] TeletypeIntro: Wait selected");
    dispatch({ type: 'SET_INTRO_CHOICE', payload: 'wait' });
    dispatch({ type: 'INCREMENT_SCORE', payload: -10 });
    setStage('splat');
  };

  const handleSip = () => {
    cancelTimer();
    console.log("[AppCore] TeletypeIntro: Sip selected");
    dispatch({ type: 'SET_INTRO_CHOICE', payload: 'sip' });
    dispatch({ type: 'INCREMENT_SCORE', payload: 40 });
    dispatch({ type: 'ADD_ITEM', payload: 'medallion' });
    dispatch({ type: 'ADD_TRAIT', payload: 'Insightful' });
    setStage('sipreset');
  };

  const renderTransitionScreen = (color, main, sub) => (
    <div className={`min-h-screen flex items-center justify-center bg-black ${color} font-mono text-2xl text-center p-6 animate-pulse`}>
      <div>
        <p aria-live="polite">{main}</p>
        <p>{sub}</p>
      </div>
    </div>
  );

  console.log("[AppCore] Rendering stage:", stage);

  return (
    <GameContext.Provider value={{ state, dispatch }}>
      {stage === 'welcome' && (
        <WelcomeScreen onEnterSimulation={() => setStageWithCancel('nameInput')} />
      )}
      {stage === 'nameInput' && (
        <PlayerNameCapture onNameSubmit={handleNameSubmit} />
      )}
      {stage === 'teletype' && (
        <TeletypeIntro
          onSip={handleSip}
          onWait={handleWait}
          onJump={handleJump}
        />
      )}
      {stage === 'portal' && <PortalTransition />}
      {stage === 'splat' && renderTransitionScreen(
        "text-red-400", "SPLAT.", "You have been hit by a truck. (Fortunately reality is... flexible.)"
      )}
      {stage === 'waitreset' && renderTransitionScreen(
        "text-yellow-300 text-xl", "You feel time rewind...", "Another chance awaits."
      )}
      {stage === 'sipreset' && renderTransitionScreen(
        "text-blue-300 text-xl", "You sip the coffee. The world blurs and reforms.", "Something new is within you."
      )}
      {stage === 'portallattice' && <PortalTransition />}
      {stage === 'game' && (
        <GameEngine
          playerName={state.playerName}
          introChoice={state.introChoice || 'jump'}
          onError={(err) => console.error("Game error:", err)}
        />
      )}
    </GameContext.Provider>
  );
};

export default AppCore;





